/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql.spriteeditor;

import java.awt.Color;
import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author simon
 */
public class Sprite
{
    private final String name;
    private final short x,y;
    private final int mask[][],data[][];

    public Sprite(final String name,final int x,final int y)
    {
        this.name=name;
        this.x=(short)x; this.y=(short)y;

        mask=new int[x*2][y];
        data=new int[x*2][y];
    }

    /**
     * @return the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return the x
     */
    public short getX()
    {
        return x;
    }

    /**
     * @return the y
     */
    public short getY()
    {
        return y;
    }

    /**
     * @return the mask
     */
    public int[][] getMask()
    {
        return mask;
    }

    public void setColour(final int dx,final int dy,Color color)
    {
        final boolean masked=color==null;

        if(masked) color=Color.BLACK;

        boolean red=!masked&&(color.getRed()>0);
        boolean blue=!masked&&(color.getBlue()>0);
        boolean green=!masked&&(color.getGreen()>0);

        int datum=data[dx/4][dy];
        int msk=data[dx/4][dy];

        switch(dx&3)
        {
            case 3 ->
            {
                datum&=0xfcfc;

                if(blue) datum|=1;
                if(red) datum|=2;
                if(green) datum|=512;

                if(masked) msk|=(1|2|512);
                else msk&=(~(1|2|512))&0xffff;
            }
            case 2 ->
            {
                datum&=0xf3f3;

                if(blue) datum|=4;
                if(red) datum|=8;
                if(green) datum|=2048;

                if(masked) msk|=(4|8|2048);
                else msk&=(~(4|8|2048))&0xffff;
            }
            case 1 ->
            {
                datum&=0xcfcf;

                if(blue) datum|=16;
                if(red) datum|=32;
                if(green) datum|=8192;

                if(masked) msk|=(16|32|8192);
                else msk=(~(16|32|8192))&0xffff;
            }
            case 0 ->
            {
                datum&=0x3f3f;

                if(blue) datum|=64;
                if(red) datum|=128;
                if(green) datum|=32768;

                if(masked) msk|=(64|128|32768);
                else msk&=(~(16|32|8192))&0xffff;
            }
        }

        data[dx/4][dy]=datum;
        mask[dx/4][dy]=msk;
    }

    public Color getColour(final int dx,final int dy)
    {
        final Color colours[]={Color.BLACK,Color.BLUE,Color.RED,Color.MAGENTA,Color.GREEN,Color.CYAN,Color.YELLOW,Color.WHITE};

        final int datum=data[dx/4][dy];
        final int msk=mask[dx/4][dy];
        int colour=0;

        switch(dx&3)
        {
            case 3 ->
            {
                if((msk&1)>0) return null;

                if((datum&1)>0) colour=1;
                if((datum&2)>0) colour+=2;
                if((datum&512)>0) colour+=4;
            }
            case 2 ->
            {
                if((msk&4)>0) return null;

                if((datum&4)>0) colour=1;
                if((datum&8)>0) colour+=2;
                if((datum&2048)>0) colour+=4;
            }
            case 1 ->
            {
                if((msk&16)>0) return null;

                if((datum&16)>0) colour=1;
                if((datum&32)>0) colour+=2;
                if((datum&8192)>0) colour+=4;
            }
            case 0 ->
            {
                if((msk&64)>0) return null;

                if((datum&64)>0) colour=1;
                if((datum&128)>0) colour+=2;
                if((datum&32768)>0) colour+=4;
            }
        }

        return colours[colour];
    }

    private static String readLine(final BufferedReader in) throws IOException
    {
        while(true)
        {
            String buffer=in.readLine();
            if(buffer==null) return null;

            if((buffer.length()>0)&&(buffer.charAt(0)!='#'))
            {
                if(buffer.contains("#")) buffer=buffer.substring(0,buffer.indexOf("#")).trim();
                return buffer;
            }
        }
    }

    public static Sprite load(final BufferedReader in) throws IOException
    {
        final String name=readLine(in);
        if(name==null) return null;

        final Sprite s=new Sprite(name,Integer.parseInt(readLine(in)),Integer.parseInt(readLine(in)));

        // Load data

        for(int b=0;b<s.y;b++)
        {
            for(int a=0;a<s.x;a++)
            {
                s.data[a][b]=Integer.parseInt(readLine(in));
            }
        }

        return s;
    }

    public void save(final PrintWriter out)
    {
        out.println("# "+getName());
        out.println(getName());
        out.println(x);
        out.println(y);

        for(int b=0;b<y;b++)
        {
            out.println("# y="+b);
            for(int a=0;a<x;a++)
            {
                out.println(data[a][b]+"\t#"+a);
            }
        }
    }

    public void clear()
    {
        for(int a=0;a<x;a++)
            for(int b=0;b<y;b++)
                data[a][b]=0;
    }

    @Override public String toString()
    {
        final StringBuilder out=new StringBuilder();

        out.append(name).append("\t").append(x).append("\t").append(y).append("\n");

        out.append(" y gfgfgfgfrbrbrbrb gfgfgfgfrbrbrbrb\n");
        out.append("   3322110033221100 3322110033221100\n");

        for(int b=0;b<y;b++)
        {
            out.append(String.format("%2d",b));

            for(int a=0;a<x;a++)
            {
                String z=Integer.toBinaryString(data[a][b]);

                while(z.length()<16) z="0"+z;

                out.append(String.format(" %16s",z));
            }

            out.append('\n');
        }

        out.append(" y gfgfgfgfrbrbrbrb gfgfgfgfrbrbrbrb\n");
        out.append("   3322110033221100 3322110033221100\n");

        return out.toString();
    }

    public int draw(final Graphics g,final int xc,final int yc)
    {
        final int box=4;

        for(int a=0;a<x*4;a++)
        {
            for(int b=0;b<y;b++)
            {
                g.setColor(getColour(a,b));
                g.fillRect(xc+a*box,yc+b*box,box,box);
            }
        }

        return yc+getY()*box;
    }

    public void autoMask()
    {
        for(int y=0;y<getY();y++)
        {
            for(int x=0;x<getX()*4;x++)
            {
                //if(getColour(x,y)>0) setMask(x,y)=1;
            }
        }
    }
}
